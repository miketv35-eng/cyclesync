-- ─────────────────────────────────────────────────────────────────────────────
-- CycleSync — Initial Database Schema
-- Run this in Supabase SQL Editor or via: supabase db push
-- ─────────────────────────────────────────────────────────────────────────────

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";   -- For geospatial queries (optional)

-- ─── Profiles ────────────────────────────────────────────────────────────────
CREATE TABLE profiles (
  id              UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username        TEXT UNIQUE,
  full_name       TEXT NOT NULL DEFAULT '',
  avatar_url      TEXT,
  bio             TEXT,
  location        TEXT,
  units           TEXT NOT NULL DEFAULT 'metric' CHECK (units IN ('metric','imperial')),
  weight_kg       NUMERIC(5,2),
  ftp_watts       INTEGER,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', NULL)
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ─── Bikes ───────────────────────────────────────────────────────────────────
CREATE TABLE bikes (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name                TEXT NOT NULL,
  type                TEXT NOT NULL CHECK (type IN ('road','gravel','mtb','endurance','ebike','tt')),
  brand               TEXT NOT NULL DEFAULT '',
  model               TEXT NOT NULL DEFAULT '',
  color               TEXT NOT NULL DEFAULT '#0ea5e9',
  weight_kg           NUMERIC(5,2),
  year                INTEGER,
  photo_url           TEXT,
  total_distance_m    BIGINT NOT NULL DEFAULT 0,
  is_retired          BOOLEAN NOT NULL DEFAULT FALSE,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE accessories (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  bike_id                 UUID NOT NULL REFERENCES bikes(id) ON DELETE CASCADE,
  name                    TEXT NOT NULL,
  category                TEXT NOT NULL CHECK (category IN ('drivetrain','wheels','computer','sensor','lights','other')),
  brand                   TEXT,
  model                   TEXT,
  installed_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  distance_at_install_m   BIGINT NOT NULL DEFAULT 0,
  service_interval_m      BIGINT,
  notes                   TEXT
);

-- ─── Rides ───────────────────────────────────────────────────────────────────
CREATE TABLE rides (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title               TEXT NOT NULL DEFAULT 'Untitled Ride',
  description         TEXT,
  distance_m          BIGINT NOT NULL DEFAULT 0,
  duration_s          INTEGER NOT NULL DEFAULT 0,
  elevation_gain_m    INTEGER NOT NULL DEFAULT 0,
  avg_speed_kmh       NUMERIC(5,2) NOT NULL DEFAULT 0,
  max_speed_kmh       NUMERIC(5,2) NOT NULL DEFAULT 0,
  avg_heart_rate      INTEGER,
  max_heart_rate      INTEGER,
  calories            INTEGER,
  avg_cadence         INTEGER,
  avg_power_w         INTEGER,
  route_geojson       JSONB,
  bike_id             UUID REFERENCES bikes(id) ON DELETE SET NULL,
  is_public           BOOLEAN NOT NULL DEFAULT TRUE,
  started_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ended_at            TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE ride_likes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ride_id     UUID NOT NULL REFERENCES rides(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(ride_id, user_id)
);

CREATE TABLE ride_comments (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ride_id     UUID NOT NULL REFERENCES rides(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content     TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Routes ──────────────────────────────────────────────────────────────────
CREATE TABLE routes (
  id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id                 UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title                   TEXT NOT NULL,
  description             TEXT,
  distance_m              BIGINT NOT NULL DEFAULT 0,
  elevation_gain_m        INTEGER NOT NULL DEFAULT 0,
  difficulty              TEXT NOT NULL CHECK (difficulty IN ('easy','moderate','hard','extreme')),
  surface                 TEXT NOT NULL CHECK (surface IN ('road','gravel','mtb','mixed')),
  route_geojson           JSONB NOT NULL,
  waypoints               JSONB NOT NULL DEFAULT '[]',
  estimated_duration_s    INTEGER NOT NULL DEFAULT 0,
  is_public               BOOLEAN NOT NULL DEFAULT TRUE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Clubs ───────────────────────────────────────────────────────────────────
CREATE TABLE clubs (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  description  TEXT,
  cover_url    TEXT,
  invite_code  TEXT UNIQUE NOT NULL DEFAULT UPPER(SUBSTRING(MD5(RANDOM()::TEXT), 1, 6)),
  is_private   BOOLEAN NOT NULL DEFAULT FALSE,
  location     TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE club_members (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  club_id     UUID NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  role        TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('owner','admin','member')),
  joined_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(club_id, user_id)
);

CREATE TABLE club_posts (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  club_id     UUID NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content     TEXT NOT NULL,
  image_url   TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE group_rides (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  club_id        UUID NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
  creator_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title          TEXT NOT NULL,
  description    TEXT,
  scheduled_at   TIMESTAMPTZ NOT NULL,
  start_lat      NUMERIC(10,7),
  start_lng      NUMERIC(10,7),
  distance_m     BIGINT,
  difficulty     TEXT,
  max_riders     INTEGER,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE ride_rsvps (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ride_id     UUID NOT NULL REFERENCES group_rides(id) ON DELETE CASCADE,
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status      TEXT NOT NULL DEFAULT 'going' CHECK (status IN ('going','maybe','not_going')),
  UNIQUE(ride_id, user_id)
);

-- ─── Social ──────────────────────────────────────────────────────────────────
CREATE TABLE followers (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  follower_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  following_id    UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- ─── Devices ─────────────────────────────────────────────────────────────────
CREATE TABLE devices (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name                TEXT NOT NULL,
  type                TEXT NOT NULL,
  brand               TEXT NOT NULL,
  model               TEXT NOT NULL,
  is_connected        BOOLEAN NOT NULL DEFAULT FALSE,
  last_sync           TIMESTAMPTZ,
  battery_level       INTEGER,
  firmware_version    TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE device_connections (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  provider        TEXT NOT NULL,
  access_token    TEXT NOT NULL,
  refresh_token   TEXT,
  expires_at      TIMESTAMPTZ,
  last_sync       TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, provider)
);

-- ─── Dashboard Layout ────────────────────────────────────────────────────────
CREATE TABLE dashboard_layouts (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID UNIQUE NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  tile_order  JSONB NOT NULL DEFAULT '[]',
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Indexes ─────────────────────────────────────────────────────────────────
CREATE INDEX rides_user_id_idx        ON rides(user_id);
CREATE INDEX rides_started_at_idx     ON rides(started_at DESC);
CREATE INDEX routes_user_id_idx       ON routes(user_id);
CREATE INDEX clubs_invite_code_idx    ON clubs(invite_code);
CREATE INDEX club_members_user_idx    ON club_members(user_id);
CREATE INDEX club_posts_club_idx      ON club_posts(club_id, created_at DESC);
CREATE INDEX followers_follower_idx   ON followers(follower_id);
CREATE INDEX followers_following_idx  ON followers(following_id);

-- ─── Row Level Security ──────────────────────────────────────────────────────
ALTER TABLE profiles           ENABLE ROW LEVEL SECURITY;
ALTER TABLE bikes              ENABLE ROW LEVEL SECURITY;
ALTER TABLE accessories        ENABLE ROW LEVEL SECURITY;
ALTER TABLE rides              ENABLE ROW LEVEL SECURITY;
ALTER TABLE ride_likes         ENABLE ROW LEVEL SECURITY;
ALTER TABLE ride_comments      ENABLE ROW LEVEL SECURITY;
ALTER TABLE routes             ENABLE ROW LEVEL SECURITY;
ALTER TABLE clubs              ENABLE ROW LEVEL SECURITY;
ALTER TABLE club_members       ENABLE ROW LEVEL SECURITY;
ALTER TABLE club_posts         ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_rides        ENABLE ROW LEVEL SECURITY;
ALTER TABLE ride_rsvps         ENABLE ROW LEVEL SECURITY;
ALTER TABLE followers          ENABLE ROW LEVEL SECURITY;
ALTER TABLE devices            ENABLE ROW LEVEL SECURITY;
ALTER TABLE device_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE dashboard_layouts  ENABLE ROW LEVEL SECURITY;

-- Profiles: public read, own write
CREATE POLICY "profiles_select" ON profiles FOR SELECT USING (TRUE);
CREATE POLICY "profiles_update" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Bikes: own only
CREATE POLICY "bikes_select"   ON bikes FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "bikes_insert"   ON bikes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "bikes_update"   ON bikes FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "bikes_delete"   ON bikes FOR DELETE USING (auth.uid() = user_id);

-- Accessories: via bike ownership
CREATE POLICY "accessories_all" ON accessories USING (
  auth.uid() = (SELECT user_id FROM bikes WHERE id = bike_id)
);

-- Rides: public rides visible to all, private only to owner
CREATE POLICY "rides_select" ON rides FOR SELECT USING (is_public OR auth.uid() = user_id);
CREATE POLICY "rides_insert" ON rides FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "rides_update" ON rides FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "rides_delete" ON rides FOR DELETE USING (auth.uid() = user_id);

-- Ride interactions: authenticated users
CREATE POLICY "likes_select"  ON ride_likes FOR SELECT USING (TRUE);
CREATE POLICY "likes_insert"  ON ride_likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "likes_delete"  ON ride_likes FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "comments_all"  ON ride_comments FOR SELECT USING (TRUE);
CREATE POLICY "comments_ins"  ON ride_comments FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Routes: public read, own write
CREATE POLICY "routes_select" ON routes FOR SELECT USING (is_public OR auth.uid() = user_id);
CREATE POLICY "routes_insert" ON routes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "routes_update" ON routes FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "routes_delete" ON routes FOR DELETE USING (auth.uid() = user_id);

-- Clubs: public clubs visible to all, private via membership
CREATE POLICY "clubs_select"  ON clubs FOR SELECT USING (
  NOT is_private OR auth.uid() = owner_id OR
  EXISTS (SELECT 1 FROM club_members WHERE club_id = clubs.id AND user_id = auth.uid())
);
CREATE POLICY "clubs_insert"  ON clubs FOR INSERT WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "clubs_update"  ON clubs FOR UPDATE USING (auth.uid() = owner_id);

-- Club members
CREATE POLICY "members_select" ON club_members FOR SELECT USING (TRUE);
CREATE POLICY "members_insert" ON club_members FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "members_delete" ON club_members FOR DELETE USING (auth.uid() = user_id);

-- Club posts (members only)
CREATE POLICY "posts_select"  ON club_posts FOR SELECT USING (
  EXISTS (SELECT 1 FROM club_members WHERE club_id = club_posts.club_id AND user_id = auth.uid())
  OR EXISTS (SELECT 1 FROM clubs WHERE id = club_posts.club_id AND NOT is_private)
);
CREATE POLICY "posts_insert"  ON club_posts FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Followers
CREATE POLICY "followers_select" ON followers FOR SELECT USING (TRUE);
CREATE POLICY "followers_insert" ON followers FOR INSERT WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "followers_delete" ON followers FOR DELETE USING (auth.uid() = follower_id);

-- Devices
CREATE POLICY "devices_own" ON devices USING (auth.uid() = user_id);
CREATE POLICY "device_conn_own" ON device_connections USING (auth.uid() = user_id);

-- Dashboard
CREATE POLICY "dashboard_own" ON dashboard_layouts USING (auth.uid() = user_id);

-- ─── Enable Realtime ─────────────────────────────────────────────────────────
-- Run in Supabase dashboard: Realtime → Enable for:
-- rides, club_posts, ride_likes, ride_comments
