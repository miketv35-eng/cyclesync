'use client'
import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import { MAPBOX_STYLES, type MapboxStyle } from '@/lib/mapbox'
import { Layers, Satellite, Map as MapIcon, Mountain } from 'lucide-react'

interface MapViewProps {
  className?: string
  style?: MapboxStyle
  initialCenter?: [number, number]
  initialZoom?: number
  showControls?: boolean
  onMapLoad?: (map: mapboxgl.Map) => void
  markers?: { lng: number; lat: number; color?: string }[]
  route?: [number, number][]
}

export function MapView({
  className,
  style: mapStyle = 'outdoors',
  initialCenter = [-1.78, 54.56],
  initialZoom = 11,
  showControls = true,
  onMapLoad,
  markers = [],
  route = [],
}: MapViewProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef = useRef<mapboxgl.Map | null>(null)
  const [activeStyle, setActiveStyle] = useState<MapboxStyle>(mapStyle)
  const [loaded, setLoaded] = useState(false)
  const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN

  useEffect(() => {
    if (!containerRef.current || mapRef.current || !token) return

    const initMap = async () => {
      const mapboxgl = (await import('mapbox-gl')).default
      await import('mapbox-gl/dist/mapbox-gl.css')

      mapboxgl.accessToken = token

      const map = new mapboxgl.Map({
        container: containerRef.current!,
        style: MAPBOX_STYLES[activeStyle],
        center: initialCenter,
        zoom: initialZoom,
        antialias: true,
        attributionControl: false,
      })

      map.addControl(new mapboxgl.NavigationControl({ showCompass: false }), 'top-right')
      map.addControl(new mapboxgl.GeolocateControl({
        positionOptions: { enableHighAccuracy: true },
        trackUserLocation: true,
        showUserHeading: true,
      }), 'top-right')

      map.on('load', () => {
        setLoaded(true)
        onMapLoad?.(map)

        // Add route line if provided
        if (route.length > 1) {
          map.addSource('route', {
            type: 'geojson',
            data: { type: 'Feature', properties: {}, geometry: { type: 'LineString', coordinates: route } }
          })
          map.addLayer({ id: 'route-line', type: 'line', source: 'route',
            layout: { 'line-join': 'round', 'line-cap': 'round' },
            paint: { 'line-color': '#0ea5e9', 'line-width': 4, 'line-opacity': 0.9 }
          })
          map.addLayer({ id: 'route-glow', type: 'line', source: 'route',
            layout: { 'line-join': 'round', 'line-cap': 'round' },
            paint: { 'line-color': '#0ea5e9', 'line-width': 10, 'line-opacity': 0.15 }
          })
        }

        // Add markers
        markers.forEach(({ lng, lat, color = '#0ea5e9' }) => {
          const el = document.createElement('div')
          el.className = 'mapbox-marker'
          el.style.cssText = `width:14px;height:14px;background:${color};border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);`
          new mapboxgl.Marker({ element: el }).setLngLat([lng, lat]).addTo(map)
        })
      })

      mapRef.current = map
    }

    initMap()
    return () => { mapRef.current?.remove(); mapRef.current = null }
  }, [token])

  const STYLE_OPTS: { key: MapboxStyle; icon: React.ElementType; label: string }[] = [
    { key: 'outdoors',  icon: Mountain,  label: 'Outdoors' },
    { key: 'streets',   icon: MapIcon,   label: 'Streets'  },
    { key: 'satellite', icon: Satellite, label: 'Satellite'},
    { key: 'dark',      icon: Layers,    label: 'Dark'     },
  ]

  function switchStyle(s: MapboxStyle) {
    setActiveStyle(s)
    mapRef.current?.setStyle(MAPBOX_STYLES[s])
  }

  return (
    <div className={cn('relative overflow-hidden rounded-2xl', className)}>
      {/* No token fallback */}
      {!token ? (
        <div className="w-full h-full bg-surface-800 flex flex-col items-center justify-center gap-3 text-slate-400">
          <MapIcon className="w-12 h-12 opacity-30" />
          <p className="text-sm">Add NEXT_PUBLIC_MAPBOX_TOKEN to enable maps</p>
        </div>
      ) : (
        <>
          <div ref={containerRef} className="w-full h-full" />
          {!loaded && (
            <div className="absolute inset-0 bg-surface-800 flex items-center justify-center">
              <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
            </div>
          )}
          {showControls && loaded && (
            <div className="absolute top-3 left-3 flex gap-1.5 bg-surface-900/90 backdrop-blur-sm rounded-xl p-1.5 border border-slate-700/60">
              {STYLE_OPTS.map(({ key, icon: Icon, label }) => (
                <button key={key} onClick={() => switchStyle(key)} title={label}
                  className={cn('p-1.5 rounded-lg transition-colors', activeStyle === key ? 'bg-brand-500 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700')}
                >
                  <Icon className="w-3.5 h-3.5" />
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}
