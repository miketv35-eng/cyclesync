'use client'

import { useEffect, useRef, useState } from 'react'
import mapboxgl from 'mapbox-gl'
import { MapWaypoint } from '@/types'

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!

interface Props {
  waypoints: MapWaypoint[]
  onWaypointAdd: (wp: MapWaypoint) => void
  onWaypointRemove: (id: string) => void
  routeGeojson?: GeoJSON.Feature | null
  mapStyle?: string
}

export default function RouteMap({ waypoints, onWaypointAdd, onWaypointRemove, routeGeojson, mapStyle = 'dark-v11' }: Props) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef       = useRef<mapboxgl.Map | null>(null)
  const markersRef   = useRef<Record<string, mapboxgl.Marker>>({})

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return

    const map = new mapboxgl.Map({
      container: containerRef.current,
      style: `mapbox://styles/mapbox/${mapStyle}`,
      center: [-1.8, 54.6],
      zoom: 11,
      attributionControl: false,
    })

    map.addControl(new mapboxgl.NavigationControl({ visualizePitch: false }), 'top-left')
    map.addControl(new mapboxgl.GeolocateControl({ positionOptions: { enableHighAccuracy: true } }), 'top-left')

    map.on('load', () => {
      map.addSource('route', {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] }
      })
      // Route casing
      map.addLayer({
        id: 'route-casing',
        type: 'line',
        source: 'route',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: { 'line-color': '#082f49', 'line-width': 8, 'line-opacity': 0.6 },
      })
      // Route line
      map.addLayer({
        id: 'route-line',
        type: 'line',
        source: 'route',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': '#0ea5e9',
          'line-width': 4,
          'line-opacity': 1,
        },
      })
    })

    map.on('click', (e) => {
      const id = `wp-${Date.now()}`
      const count = Object.keys(markersRef.current).length
      onWaypointAdd({
        id, lat: e.lngLat.lat, lng: e.lngLat.lng,
        type: count === 0 ? 'start' : 'waypoint',
      })
    })

    mapRef.current = map
    return () => { map.remove(); mapRef.current = null }
  }, [])

  // Sync waypoints → markers
  useEffect(() => {
    const map = mapRef.current
    if (!map) return

    // Remove old markers
    Object.keys(markersRef.current).forEach(id => {
      if (!waypoints.find(w => w.id === id)) {
        markersRef.current[id].remove()
        delete markersRef.current[id]
      }
    })

    // Add new markers
    waypoints.forEach((wp, i) => {
      if (markersRef.current[wp.id]) return

      const isFirst = i === 0
      const isLast  = i === waypoints.length - 1

      const el = document.createElement('div')
      el.style.cssText = `
        width: 28px; height: 28px; border-radius: 50%;
        background: ${isFirst ? '#22c55e' : isLast ? '#ef4444' : '#0ea5e9'};
        border: 2.5px solid white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.4);
        display: flex; align-items: center; justify-content: center;
        color: white; font-size: 10px; font-weight: 700; cursor: pointer;
        font-family: system-ui;
      `
      el.textContent = isFirst ? 'S' : isLast ? 'E' : String(i)

      el.addEventListener('click', (e) => {
        e.stopPropagation()
        onWaypointRemove(wp.id)
      })

      const marker = new mapboxgl.Marker({ element: el })
        .setLngLat([wp.lng, wp.lat])
        .addTo(map)
      markersRef.current[wp.id] = marker
    })
  }, [waypoints, onWaypointRemove])

  // Update route line
  useEffect(() => {
    const map = mapRef.current
    if (!map || !map.isStyleLoaded()) return
    const source = map.getSource('route') as mapboxgl.GeoJSONSource
    if (!source) return
    if (routeGeojson) {
      source.setData({ type: 'FeatureCollection', features: [routeGeojson] })
    } else if (waypoints.length >= 2) {
      // Simple straight line fallback
      source.setData({
        type: 'FeatureCollection',
        features: [{
          type: 'Feature',
          geometry: { type: 'LineString', coordinates: waypoints.map(w => [w.lng, w.lat]) },
          properties: {}
        }]
      })
    } else {
      source.setData({ type: 'FeatureCollection', features: [] })
    }
  }, [routeGeojson, waypoints])

  return <div ref={containerRef} className="w-full h-full" />
}
