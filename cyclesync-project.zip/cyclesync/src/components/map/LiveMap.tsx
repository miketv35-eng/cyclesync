'use client'

import { useEffect, useRef } from 'react'
import mapboxgl from 'mapbox-gl'

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!

interface Props {
  coords: Array<{ lat: number; lng: number; alt?: number }>
  status: 'idle' | 'active' | 'paused' | 'completed'
}

export default function LiveMap({ coords, status }: Props) {
  const containerRef = useRef<HTMLDivElement>(null)
  const mapRef       = useRef<mapboxgl.Map | null>(null)
  const markerRef    = useRef<mapboxgl.Marker | null>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const map = new mapboxgl.Map({
      container: containerRef.current,
      style: 'mapbox://styles/mapbox/dark-v11',
      center: [-1.8, 54.6],
      zoom: 13,
      attributionControl: false,
    })

    map.addControl(new mapboxgl.GeolocateControl({
      positionOptions: { enableHighAccuracy: true },
      trackUserLocation: true,
      showUserHeading: true,
    }), 'top-left')

    map.on('load', () => {
      // Route line
      map.addSource('route', {
        type: 'geojson',
        data: { type: 'FeatureCollection', features: [] }
      })
      map.addLayer({
        id: 'route-line',
        type: 'line',
        source: 'route',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': '#0ea5e9',
          'line-width': 4,
          'line-opacity': 0.9,
        },
      })
    })

    // Marker
    const el = document.createElement('div')
    el.className = 'w-5 h-5 rounded-full bg-brand-400 border-2 border-white shadow-lg'
    el.style.cssText = 'width:20px;height:20px;border-radius:50%;background:#0ea5e9;border:2px solid white;box-shadow:0 0 0 4px rgba(14,165,233,0.3)'

    markerRef.current = new mapboxgl.Marker({ element: el }).setLngLat([-1.8, 54.6]).addTo(map)

    mapRef.current = map
    return () => map.remove()
  }, [])

  // Update route line + follow user
  useEffect(() => {
    const map = mapRef.current
    if (!map || coords.length === 0 || !map.isStyleLoaded()) return

    const geojson: GeoJSON.Feature = {
      type: 'Feature',
      geometry: {
        type: 'LineString',
        coordinates: coords.map(c => [c.lng, c.lat, c.alt ?? 0])
      },
      properties: {}
    }

    const source = map.getSource('route') as mapboxgl.GeoJSONSource
    source?.setData({ type: 'FeatureCollection', features: [geojson] })

    const last = coords[coords.length - 1]
    markerRef.current?.setLngLat([last.lng, last.lat])

    if (status === 'active') {
      map.easeTo({ center: [last.lng, last.lat], zoom: 15, duration: 500 })
    }
  }, [coords, status])

  return (
    <div ref={containerRef} className="w-full h-full bg-surface-900"
      style={{ minHeight: '50vh' }}>
      {!process.env.NEXT_PUBLIC_MAPBOX_TOKEN && (
        <div className="absolute inset-0 flex items-center justify-center bg-surface-900 text-slate-400 text-sm">
          Add NEXT_PUBLIC_MAPBOX_TOKEN to enable map
        </div>
      )}
    </div>
  )
}
