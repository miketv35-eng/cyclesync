'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { createClient } from '@/lib/supabase/client'
import { Profile } from '@/types'
import { getInitials, cn } from '@/lib/utils'
import {
  LayoutDashboard, Navigation, Activity, Map, Users, CloudSun,
  Bike, Cpu, User, Settings, Bell, LogOut, Menu, X, Zap, Rss,
  ChevronRight, Radio
} from 'lucide-react'
import { toast } from 'sonner'

const NAV_ITEMS = [
  { href: '/dashboard',  label: 'Dashboard',  icon: LayoutDashboard },
  { href: '/ride',       label: 'Live Ride',   icon: Radio,    badge: 'LIVE' },
  { href: '/routes',     label: 'Routes',      icon: Map },
  { href: '/feed',       label: 'Feed',        icon: Rss },
  { href: '/clubs',      label: 'Clubs',       icon: Users },
  { href: '/bikes',      label: 'Garage',      icon: Bike },
  { href: '/devices',    label: 'Devices',     icon: Cpu },
]

const BOTTOM_NAV = [
  { href: '/profile',  label: 'Profile',  icon: User },
  { href: '/settings', label: 'Settings', icon: Settings },
]

interface Props {
  children: React.ReactNode
  profile: Profile | null
}

export default function AppShell({ children, profile }: Props) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [collapsed, setCollapsed]     = useState(false)
  const pathname = usePathname()
  const router   = useRouter()
  const supabase = createClient()

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  const isActive = (href: string) => pathname.startsWith(href)

  return (
    <div className="flex h-screen overflow-hidden bg-[#060c18]">

      {/* Mobile overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        className={cn(
          'fixed lg:relative inset-y-0 left-0 z-50 flex flex-col',
          'bg-surface-900/95 backdrop-blur-xl border-r border-surface-800',
          'transition-all duration-300 ease-in-out',
          collapsed ? 'w-[72px]' : 'w-60',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Logo */}
        <div className={cn('flex items-center h-16 px-4 border-b border-surface-800 shrink-0', collapsed && 'justify-center')}>
          <Link href="/dashboard" className="flex items-center gap-3 min-w-0" onClick={() => setSidebarOpen(false)}>
            <div className="w-8 h-8 rounded-xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4 text-brand-400" />
            </div>
            <AnimatePresence>
              {!collapsed && (
                <motion.span initial={{ opacity: 0, width: 0 }} animate={{ opacity: 1, width: 'auto' }} exit={{ opacity: 0, width: 0 }}
                  className="font-display font-bold text-white text-lg tracking-tight overflow-hidden whitespace-nowrap">
                  CycleSync
                </motion.span>
              )}
            </AnimatePresence>
          </Link>
          {/* Collapse toggle (desktop) */}
          <button onClick={() => setCollapsed(c => !c)}
            className="hidden lg:flex ml-auto w-6 h-6 items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-surface-800 transition-all shrink-0">
            <ChevronRight className={cn('w-3.5 h-3.5 transition-transform', collapsed && 'rotate-180')} />
          </button>
          {/* Mobile close */}
          <button onClick={() => setSidebarOpen(false)} className="ml-auto lg:hidden text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main nav */}
        <nav className="flex-1 py-4 px-2 space-y-0.5 overflow-y-auto no-scrollbar">
          {NAV_ITEMS.map(item => {
            const active = isActive(item.href)
            return (
              <Link key={item.href} href={item.href} onClick={() => setSidebarOpen(false)}
                className={cn(
                  'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-150 group',
                  collapsed && 'justify-center px-2',
                  active
                    ? 'bg-brand-500/10 text-brand-400 border border-brand-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-surface-800/60'
                )}>
                <item.icon className={cn('shrink-0 transition-colors', active ? 'text-brand-400' : 'text-slate-400 group-hover:text-white', collapsed ? 'w-5 h-5' : 'w-4 h-4')} />
                <AnimatePresence>
                  {!collapsed && (
                    <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="flex-1 truncate">
                      {item.label}
                    </motion.span>
                  )}
                </AnimatePresence>
                {!collapsed && item.badge && (
                  <span className="text-[9px] font-bold bg-brand-500/20 text-brand-400 border border-brand-500/30 rounded-full px-1.5 py-0.5 tracking-wider">
                    {item.badge}
                  </span>
                )}
              </Link>
            )
          })}
        </nav>

        {/* Bottom nav */}
        <div className="px-2 pb-4 border-t border-surface-800 pt-3 space-y-0.5">
          {BOTTOM_NAV.map(item => {
            const active = isActive(item.href)
            return (
              <Link key={item.href} href={item.href} onClick={() => setSidebarOpen(false)}
                className={cn(
                  'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-150 group',
                  collapsed && 'justify-center px-2',
                  active
                    ? 'bg-brand-500/10 text-brand-400 border border-brand-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-surface-800/60'
                )}>
                <item.icon className={cn('shrink-0 transition-colors', active ? 'text-brand-400' : 'text-slate-400 group-hover:text-white', collapsed ? 'w-5 h-5' : 'w-4 h-4')} />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </Link>
            )
          })}

          {/* User + logout */}
          <div className={cn('flex items-center gap-3 rounded-xl px-3 py-2 mt-2', collapsed && 'justify-center px-2')}>
            <div className={cn('shrink-0 rounded-full bg-gradient-to-br from-brand-500 to-indigo-500 flex items-center justify-center text-white font-bold text-xs select-none', collapsed ? 'w-9 h-9' : 'w-7 h-7')}>
              {profile?.avatar_url
                ? <img src={profile.avatar_url} alt="" className="w-full h-full rounded-full object-cover" />
                : getInitials(profile?.full_name || profile?.username || 'U')}
            </div>
            {!collapsed && (
              <>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold text-white truncate">{profile?.full_name || profile?.username}</div>
                  <div className="text-[10px] text-slate-500 truncate">{profile?.total_rides} rides</div>
                </div>
                <button onClick={handleLogout} className="text-slate-500 hover:text-red-400 transition-colors shrink-0" title="Sign out">
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </motion.aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar (mobile + notifications) */}
        <header className="h-16 flex items-center justify-between px-4 lg:px-6 border-b border-surface-800 bg-surface-900/50 backdrop-blur-sm shrink-0 lg:hidden">
          <button onClick={() => setSidebarOpen(true)} className="text-slate-400 hover:text-white transition-colors">
            <Menu className="w-6 h-6" />
          </button>
          <Link href="/dashboard" className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-brand-400" />
            <span className="font-display font-bold text-white">CycleSync</span>
          </Link>
          <Link href="/notifications" className="relative text-slate-400 hover:text-white transition-colors">
            <Bell className="w-5 h-5" />
          </Link>
        </header>

        {/* Page */}
        <main className="flex-1 overflow-y-auto">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="h-full"
          >
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  )
}
