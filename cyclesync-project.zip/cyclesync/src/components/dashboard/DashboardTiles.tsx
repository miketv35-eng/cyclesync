'use client'
import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor,
  useSensor, useSensors, DragEndEvent
} from '@dnd-kit/core'
import {
  arrayMove, SortableContext, sortableKeyboardCoordinates,
  rectSortingStrategy, useSortable
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { cn } from '@/lib/utils'
import {
  Play, Map, History, BarChart2, Cloud, Navigation,
  Users, Cpu, Wrench, Calendar, Zap, Trophy, GripVertical
} from 'lucide-react'

interface Tile {
  id: string
  label: string
  href: string
  icon: React.ElementType
  gradient: string
  stat?: string
  sub?: string
  size?: 'sm' | 'md' | 'lg'
}

const DEFAULT_TILES: Tile[] = [
  { id: 'start-ride',  label: 'Start Ride',    href: '/ride',      icon: Play,      gradient: 'from-emerald-500 to-teal-600',   stat: 'Ready',     sub: 'GPS acquired',        size: 'lg' },
  { id: 'plan-route',  label: 'Plan Route',    href: '/routes/new',icon: Map,       gradient: 'from-brand-500 to-cyan-500',     stat: '3 saved',   sub: 'Open planner',        size: 'lg' },
  { id: 'ride-history',label: 'Ride History',  href: '/profile',   icon: History,   gradient: 'from-violet-500 to-purple-600',  stat: '47 rides',  sub: 'All time',            size: 'md' },
  { id: 'stats',       label: 'Weekly Stats',  href: '/profile',   icon: BarChart2, gradient: 'from-orange-500 to-red-500',     stat: '284 km',    sub: 'This week',           size: 'md' },
  { id: 'weather',     label: 'Weather',       href: '/dashboard', icon: Cloud,     gradient: 'from-sky-500 to-blue-600',       stat: '9°C',       sub: 'Partly cloudy',       size: 'md' },
  { id: 'routes',      label: 'Saved Routes',  href: '/routes',    icon: Navigation,gradient: 'from-amber-500 to-yellow-600',   stat: '12 routes', sub: 'Ready to ride',       size: 'md' },
  { id: 'clubs',       label: 'My Clubs',      href: '/clubs',     icon: Users,     gradient: 'from-pink-500 to-rose-600',      stat: '2 clubs',   sub: '3 upcoming rides',    size: 'md' },
  { id: 'devices',     label: 'Devices',       href: '/devices',   icon: Cpu,       gradient: 'from-indigo-500 to-blue-600',    stat: '2 linked',  sub: 'All connected',       size: 'sm' },
  { id: 'garage',      label: 'Bike Garage',   href: '/bikes',     icon: Wrench,    gradient: 'from-slate-500 to-slate-600',    stat: '2 bikes',   sub: 'Serviced',            size: 'sm' },
  { id: 'upcoming',    label: 'Upcoming',      href: '/routes',    icon: Calendar,  gradient: 'from-teal-500 to-emerald-600',   stat: 'Sat 7am',   sub: 'Group ride',          size: 'sm' },
  { id: 'segments',    label: 'Segments',      href: '/profile',   icon: Zap,       gradient: 'from-yellow-500 to-orange-500',  stat: '3 PRs',     sub: 'This week',           size: 'sm' },
  { id: 'achievements',label: 'Trophies',      href: '/profile',   icon: Trophy,    gradient: 'from-amber-400 to-yellow-500',   stat: '24 badges', sub: 'Unlock more',         size: 'sm' },
]

function SortableTile({ tile, editing }: { tile: Tile; editing: boolean }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: tile.id })
  const Icon = tile.icon

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : undefined,
  }

  const isLarge = tile.size === 'lg'
  const isMed   = tile.size === 'md'

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        'group',
        isLarge && 'col-span-2 row-span-1',
        isMed   && 'col-span-1',
        isDragging && 'opacity-60',
      )}
    >
      <Link href={editing ? '#' : tile.href} onClick={e => editing && e.preventDefault()}>
        <motion.div
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.98 }}
          className={cn(
            'relative rounded-2xl overflow-hidden h-full min-h-[120px] cursor-pointer',
            'bg-gradient-to-br', tile.gradient,
            'shadow-lg hover:shadow-xl transition-shadow',
            editing && 'cursor-grab active:cursor-grabbing ring-2 ring-white/20',
          )}
          {...(editing ? { ...attributes, ...listeners } : {})}
        >
          {/* Noise texture overlay */}
          <div className="absolute inset-0 bg-black/10" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E")` }} />

          <div className="relative p-4 flex flex-col h-full">
            <div className="flex items-start justify-between">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
                <Icon className="w-5 h-5 text-white" />
              </div>
              {editing && (
                <div className="opacity-50">
                  <GripVertical className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
            <div className="mt-auto pt-3">
              {tile.stat && (
                <div className="text-2xl font-bold text-white font-stat leading-none">{tile.stat}</div>
              )}
              <div className="text-sm font-semibold text-white/90 mt-1">{tile.label}</div>
              {tile.sub && (
                <div className="text-xs text-white/60 mt-0.5">{tile.sub}</div>
              )}
            </div>
          </div>
        </motion.div>
      </Link>
    </div>
  )
}

export function DashboardTiles() {
  const [tiles, setTiles] = useState(DEFAULT_TILES)
  const [editing, setEditing] = useState(false)

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  )

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event
    if (over && active.id !== over.id) {
      setTiles(items => {
        const from = items.findIndex(i => i.id === active.id)
        const to   = items.findIndex(i => i.id === over.id)
        return arrayMove(items, from, to)
      })
    }
  }, [])

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-semibold text-slate-300">Quick Access</h2>
        <button
          onClick={() => setEditing(!editing)}
          className={cn(
            'text-xs px-3 py-1.5 rounded-lg transition-colors font-medium',
            editing
              ? 'bg-brand-500 text-white'
              : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
          )}
        >
          {editing ? '✓ Done' : 'Customise'}
        </button>
      </div>

      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={tiles.map(t => t.id)} strategy={rectSortingStrategy}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 auto-rows-fr">
            {tiles.map(tile => (
              <SortableTile key={tile.id} tile={tile} editing={editing} />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  )
}
