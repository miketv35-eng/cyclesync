'use client'

import { useState, useCallback } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor,
  useSensor, useSensors, DragEndEvent
} from '@dnd-kit/core'
import {
  arrayMove, SortableContext, sortableKeyboardCoordinates,
  rectSortingStrategy, useSortable
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import {
  Radio, Map, Activity, Users, CloudSun, Bike, Cpu, Rss,
  Navigation, TrendingUp, GripVertical, ArrowRight, Flame,
  Mountain, Zap, Clock, Trophy, MoreHorizontal
} from 'lucide-react'
import { Profile, Ride } from '@/types'
import { formatDistance, formatDurationHuman, formatRelativeTime, cn } from '@/lib/utils'
import { createClient } from '@/lib/supabase/client'
import { toast } from 'sonner'

// ── Tile definitions ──────────────────────────────────────────────────────

const DEFAULT_TILES = [
  { id: 'ride',      label: 'Start Ride',       href: '/ride',      icon: 'Radio',      color: 'brand',   description: 'Track your next ride' },
  { id: 'routes',    label: 'Plan Route',        href: '/routes',    icon: 'Map',        color: 'indigo',  description: 'Build your perfect route' },
  { id: 'feed',      label: 'Activity Feed',     href: '/feed',      icon: 'Rss',        color: 'cyan',    description: 'See what riders are up to' },
  { id: 'clubs',     label: 'Clubs',             href: '/clubs',     icon: 'Users',      color: 'violet',  description: 'Your cycling groups' },
  { id: 'weather',   label: 'Weather',           href: '/dashboard', icon: 'CloudSun',   color: 'amber',   description: 'Ride conditions today' },
  { id: 'stats',     label: 'Weekly Stats',      href: '/dashboard', icon: 'TrendingUp', color: 'emerald', description: 'Your performance summary' },
  { id: 'bikes',     label: 'Bike Garage',       href: '/bikes',     icon: 'Bike',       color: 'rose',    description: 'Manage your fleet' },
  { id: 'devices',   label: 'Devices',           href: '/devices',   icon: 'Cpu',        color: 'slate',   description: 'Connected hardware' },
]

const ICON_MAP: Record<string, React.ComponentType<any>> = {
  Radio, Map, Activity, Users, CloudSun, Bike, Cpu, Rss,
  Navigation, TrendingUp, Flame, Mountain, Zap, Clock,
}

const COLOR_MAP: Record<string, { bg: string; icon: string; border: string; shadow: string }> = {
  brand:   { bg: 'from-brand-500/15 to-brand-600/5',    icon: 'text-brand-400',   border: 'border-brand-500/20',  shadow: 'shadow-brand-500/10' },
  indigo:  { bg: 'from-indigo-500/15 to-indigo-600/5',  icon: 'text-indigo-400',  border: 'border-indigo-500/20', shadow: 'shadow-indigo-500/10' },
  cyan:    { bg: 'from-cyan-500/15 to-cyan-600/5',      icon: 'text-cyan-400',    border: 'border-cyan-500/20',   shadow: 'shadow-cyan-500/10' },
  violet:  { bg: 'from-violet-500/15 to-violet-600/5',  icon: 'text-violet-400',  border: 'border-violet-500/20', shadow: 'shadow-violet-500/10' },
  amber:   { bg: 'from-amber-500/15 to-amber-600/5',    icon: 'text-amber-400',   border: 'border-amber-500/20',  shadow: 'shadow-amber-500/10' },
  emerald: { bg: 'from-emerald-500/15 to-emerald-600/5',icon: 'text-emerald-400', border: 'border-emerald-500/20',shadow: 'shadow-emerald-500/10' },
  rose:    { bg: 'from-rose-500/15 to-rose-600/5',      icon: 'text-rose-400',    border: 'border-rose-500/20',   shadow: 'shadow-rose-500/10' },
  slate:   { bg: 'from-slate-500/15 to-slate-600/5',    icon: 'text-slate-400',   border: 'border-slate-500/20',  shadow: 'shadow-slate-500/10' },
}

// ── Sortable tile ─────────────────────────────────────────────────────────

interface TileData { id: string; label: string; href: string; icon: string; color: string; description: string }

function SortableTile({ tile, editing }: { tile: TileData; editing: boolean }) {
  const {
    attributes, listeners, setNodeRef, transform, transition, isDragging
  } = useSortable({ id: tile.id })

  const style = { transform: CSS.Transform.toString(transform), transition }
  const IconComp = ICON_MAP[tile.icon] || Zap
  const colors   = COLOR_MAP[tile.color] || COLOR_MAP.brand

  const inner = (
    <div className={cn(
      'relative rounded-2xl p-5 border cursor-pointer transition-all duration-200 group h-full',
      'bg-gradient-to-br', colors.bg, colors.border,
      isDragging ? 'opacity-50 scale-95 shadow-2xl z-50' : 'hover:-translate-y-0.5 hover:shadow-xl',
      editing && 'cursor-grab active:cursor-grabbing',
    )}>
      {editing && (
        <div className="absolute top-3 right-3 text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity" {...(editing ? listeners : {})}>
          <GripVertical className="w-4 h-4" />
        </div>
      )}
      <div className={cn('w-10 h-10 rounded-xl bg-black/20 flex items-center justify-center mb-4', colors.icon)}>
        <IconComp className="w-5 h-5" />
      </div>
      <div className="font-display font-semibold text-white text-sm mb-1">{tile.label}</div>
      <div className="text-xs text-slate-400 leading-relaxed">{tile.description}</div>
      {!editing && (
        <div className={cn('absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity', colors.icon)}>
          <ArrowRight className="w-4 h-4" />
        </div>
      )}
    </div>
  )

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...(!editing ? {} : listeners)} className="min-h-[130px]">
      {editing ? inner : <Link href={tile.href} className="block h-full">{inner}</Link>}
    </div>
  )
}

// ── Main component ────────────────────────────────────────────────────────

interface Props {
  profile: Profile | null
  recentRides: Ride[]
  savedLayout: string[] | null
}

export default function DashboardClient({ profile, recentRides, savedLayout }: Props) {
  const [tiles, setTiles] = useState<TileData[]>(() => {
    if (savedLayout) {
      const map = Object.fromEntries(DEFAULT_TILES.map(t => [t.id, t]))
      return savedLayout.map(id => map[id]).filter(Boolean)
    }
    return DEFAULT_TILES
  })
  const [editing, setEditing] = useState(false)

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  )

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event
    if (over && active.id !== over.id) {
      setTiles(items => {
        const oldIndex = items.findIndex(i => i.id === active.id)
        const newIndex = items.findIndex(i => i.id === over.id)
        return arrayMove(items, oldIndex, newIndex)
      })
    }
  }

  const saveLayout = useCallback(async () => {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    await supabase.from('dashboard_layouts').upsert({
      user_id: user.id,
      tile_order: tiles.map(t => t.id),
      updated_at: new Date().toISOString(),
    })
    setEditing(false)
    toast.success('Dashboard saved!')
  }, [tiles])

  const totalKm   = recentRides.reduce((s, r) => s + r.distance_km, 0)
  const totalElev = recentRides.reduce((s, r) => s + (r.elevation_m || 0), 0)
  const weekKm    = recentRides.filter(r => {
    const d = new Date(r.started_at); const now = new Date()
    return now.getTime() - d.getTime() < 7 * 86400000
  }).reduce((s, r) => s + r.distance_km, 0)

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  return (
    <div className="max-w-6xl mx-auto p-4 lg:p-8 space-y-8">

      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
        className="flex items-start justify-between gap-4">
        <div>
          <p className="text-slate-400 text-sm mb-1">{greeting},</p>
          <h1 className="font-display text-3xl font-bold text-white">
            {profile?.full_name?.split(' ')[0] || profile?.username || 'Rider'} 👋
          </h1>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {editing ? (
            <>
              <button onClick={() => setEditing(false)} className="cs-btn-ghost text-xs px-3 py-2">Cancel</button>
              <button onClick={saveLayout} className="cs-btn-primary text-xs px-3 py-2">Save Layout</button>
            </>
          ) : (
            <button onClick={() => setEditing(true)} className="cs-btn-ghost text-xs px-3 py-2 gap-1.5">
              <GripVertical className="w-3.5 h-3.5" />Customise
            </button>
          )}
        </div>
      </motion.div>

      {/* Quick stats */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Rides',    value: profile?.total_rides ?? 0,                 icon: Activity,  color: 'text-brand-400',   unit: '' },
          { label: 'Total Distance', value: `${(profile?.total_km ?? 0).toFixed(0)}`,  icon: Navigation, color: 'text-emerald-400', unit: ' km' },
          { label: 'This Week',      value: `${weekKm.toFixed(1)}`,                    icon: TrendingUp, color: 'text-amber-400',   unit: ' km' },
          { label: 'Elevation',      value: `${(profile?.total_elevation_m ?? 0).toFixed(0)}`, icon: Mountain, color: 'text-violet-400', unit: ' m' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.05 }}
            className="cs-card flex items-center gap-4">
            <div className={cn('w-10 h-10 rounded-xl bg-surface-800 flex items-center justify-center shrink-0', s.color)}>
              <s.icon className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className={cn('stat-number text-2xl font-bold', s.color)}>
                {s.value}<span className="text-base font-normal text-slate-400">{s.unit}</span>
              </div>
              <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Tiles grid */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
        {editing && (
          <p className="text-xs text-slate-400 mb-3 flex items-center gap-1.5">
            <GripVertical className="w-3.5 h-3.5" />Drag tiles to rearrange your dashboard
          </p>
        )}
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={tiles.map(t => t.id)} strategy={rectSortingStrategy}>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {tiles.map(tile => (
                <SortableTile key={tile.id} tile={tile} editing={editing} />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      </motion.div>

      {/* Recent rides */}
      {recentRides.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-white">Recent Rides</h2>
            <Link href="/feed" className="text-xs text-brand-400 hover:text-brand-300 transition-colors flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="space-y-2">
            {recentRides.map((ride, i) => (
              <motion.div key={ride.id}
                initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.05 }}
                className="cs-card flex items-center gap-4 hover:border-surface-700 transition-colors cursor-pointer group p-4">
                <div className="w-10 h-10 rounded-xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center shrink-0">
                  <Activity className="w-5 h-5 text-brand-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm text-white truncate">{ride.name}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{formatRelativeTime(ride.started_at)}</div>
                </div>
                <div className="flex items-center gap-4 shrink-0 text-right">
                  <div>
                    <div className="stat-number text-sm text-white font-bold">{ride.distance_km.toFixed(1)}</div>
                    <div className="text-[10px] text-slate-500">km</div>
                  </div>
                  <div className="hidden sm:block">
                    <div className="stat-number text-sm text-white font-bold">{formatDurationHuman(ride.duration_sec)}</div>
                    <div className="text-[10px] text-slate-500">time</div>
                  </div>
                  <div className="hidden md:block">
                    <div className="stat-number text-sm text-emerald-400 font-bold">{ride.avg_speed_kmh?.toFixed(1) ?? '—'}</div>
                    <div className="text-[10px] text-slate-500">avg km/h</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Start first ride CTA */}
      {recentRides.length === 0 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}
          className="relative overflow-hidden rounded-3xl border border-brand-500/20 bg-gradient-to-br from-brand-500/10 to-indigo-500/5 p-8 text-center">
          <div className="absolute inset-0 bg-gradient-radial from-brand-500/5 to-transparent pointer-events-none" />
          <div className="w-16 h-16 rounded-2xl bg-brand-500/15 border border-brand-500/20 flex items-center justify-center mx-auto mb-4">
            <Radio className="w-8 h-8 text-brand-400" />
          </div>
          <h3 className="font-display text-xl font-bold text-white mb-2">Start your first ride</h3>
          <p className="text-slate-400 text-sm mb-6 max-w-sm mx-auto">Track your distance, speed, and elevation with live GPS recording.</p>
          <Link href="/ride" className="cs-btn-primary inline-flex">
            <Radio className="w-4 h-4" /> Start Riding
          </Link>
        </motion.div>
      )}
    </div>
  )
}
