'use client'
import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '@/hooks/useAuth'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, Map, Play, BarChart2, Users, Cloud,
  Wrench, Cpu, Settings, LogOut, Menu, X, Bike, Bell, ChevronRight
} from 'lucide-react'

const NAV = [
  { href: '/dashboard', label: 'Dashboard',  icon: LayoutDashboard },
  { href: '/routes',    label: 'Routes',      icon: Map },
  { href: '/ride',      label: 'Start Ride',  icon: Play, accent: true },
  { href: '/clubs',     label: 'Clubs',       icon: Users },
  { href: '/bikes',     label: 'Garage',      icon: Wrench },
  { href: '/devices',   label: 'Devices',     icon: Cpu },
  { href: '/profile',   label: 'Profile',     icon: BarChart2 },
]

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const { profile, signOut } = useAuth()
  const [expanded, setExpanded] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  const initials = profile?.full_name?.split(' ').map(n => n[0]).join('').toUpperCase() ?? 'CS'

  return (
    <div className="flex h-screen overflow-hidden bg-surface-950">
      {/* Desktop Sidebar */}
      <aside className={cn(
        'hidden md:flex flex-col border-r border-slate-800 bg-surface-900 transition-all duration-300 flex-shrink-0',
        expanded ? 'w-56' : 'w-16'
      )}>
        {/* Logo */}
        <div className="flex items-center h-16 px-4 border-b border-slate-800 flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-brand-500 flex items-center justify-center flex-shrink-0">
            <Bike className="w-4 h-4 text-white" />
          </div>
          <AnimatePresence>
            {expanded && (
              <motion.span initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -8 }}
                className="ml-3 font-display font-bold text-white text-lg whitespace-nowrap"
              >CycleSync</motion.span>
            )}
          </AnimatePresence>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
          {NAV.map(({ href, label, icon: Icon, accent }) => {
            const active = pathname === href || (href !== '/dashboard' && pathname.startsWith(href))
            return (
              <Link key={href} href={href}
                className={cn(
                  'flex items-center gap-3 px-2.5 py-2.5 rounded-xl transition-all group relative',
                  active ? 'bg-brand-500/15 text-brand-400' : 'text-slate-400 hover:text-white hover:bg-slate-800/60',
                  accent && !active && 'text-emerald-400 hover:text-emerald-300 hover:bg-emerald-400/10',
                )}
              >
                <Icon className={cn('w-5 h-5 flex-shrink-0', accent && !active && 'text-emerald-400')} />
                <AnimatePresence>
                  {expanded && (
                    <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="text-sm font-medium whitespace-nowrap"
                    >{label}</motion.span>
                  )}
                </AnimatePresence>
                {active && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-brand-500 rounded-full" />}
              </Link>
            )
          })}
        </nav>

        {/* Bottom */}
        <div className="px-2 py-4 border-t border-slate-800 space-y-1">
          <Link href="/settings" className={cn('flex items-center gap-3 px-2.5 py-2.5 rounded-xl transition-all text-slate-400 hover:text-white hover:bg-slate-800/60', pathname === '/settings' && 'bg-brand-500/15 text-brand-400')}>
            <Settings className="w-5 h-5 flex-shrink-0" />
            {expanded && <motion.span className="text-sm font-medium">Settings</motion.span>}
          </Link>
          <button onClick={signOut} className="w-full flex items-center gap-3 px-2.5 py-2.5 rounded-xl transition-all text-slate-400 hover:text-red-400 hover:bg-red-400/10">
            <LogOut className="w-5 h-5 flex-shrink-0" />
            {expanded && <span className="text-sm font-medium">Sign out</span>}
          </button>
          <button onClick={() => setExpanded(!expanded)} className="w-full flex items-center justify-center py-2 text-slate-600 hover:text-slate-400 transition-colors">
            <ChevronRight className={cn('w-4 h-4 transition-transform', expanded && 'rotate-180')} />
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="h-16 flex items-center justify-between px-4 md:px-6 border-b border-slate-800 bg-surface-900/80 backdrop-blur-sm flex-shrink-0">
          <button className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white" onClick={() => setMobileOpen(true)}>
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1" />
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-500 rounded-full" />
            </button>
            <Link href="/profile" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-xs font-bold text-white">
                {initials}
              </div>
            </Link>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden"
              onClick={() => setMobileOpen(false)}
            />
            <motion.div initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }} transition={{ type: 'spring', damping: 25 }}
              className="fixed left-0 top-0 bottom-0 w-72 bg-surface-900 border-r border-slate-800 z-50 md:hidden flex flex-col"
            >
              <div className="flex items-center justify-between h-16 px-5 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-brand-500 flex items-center justify-center">
                    <Bike className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-display font-bold text-white text-lg">CycleSync</span>
                </div>
                <button onClick={() => setMobileOpen(false)} className="p-2 rounded-lg text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
                {NAV.map(({ href, label, icon: Icon, accent }) => {
                  const active = pathname === href || (href !== '/dashboard' && pathname.startsWith(href))
                  return (
                    <Link key={href} href={href} onClick={() => setMobileOpen(false)}
                      className={cn('flex items-center gap-3 px-3 py-3 rounded-xl transition-all',
                        active ? 'bg-brand-500/15 text-brand-400' : 'text-slate-400 hover:text-white hover:bg-slate-800/60',
                        accent && !active && 'text-emerald-400'
                      )}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-sm font-medium">{label}</span>
                    </Link>
                  )
                })}
              </nav>
              <div className="px-3 py-4 border-t border-slate-800">
                <button onClick={signOut} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-400/10 transition-all">
                  <LogOut className="w-5 h-5" />
                  <span className="text-sm font-medium">Sign out</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
