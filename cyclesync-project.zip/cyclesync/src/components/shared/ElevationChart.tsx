'use client'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { generateElevationProfile } from '@/lib/mapbox'

interface Props {
  points?: number
  data?: { dist: number; elev: number }[]
  height?: number
  color?: string
}

export function ElevationChart({ points = 30, data, height = 120, color = '#0ea5e9' }: Props) {
  const chartData = data ?? generateElevationProfile(points).map((elev, i) => ({
    dist: parseFloat(((i / points) * 34.2).toFixed(1)),
    elev,
  }))

  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={chartData} margin={{ top: 4, right: 0, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="elevGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.3} />
            <stop offset="95%" stopColor={color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
        <XAxis dataKey="dist" tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false}
          tickFormatter={(v) => `${v}km`} interval="preserveStartEnd" />
        <YAxis tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false}
          tickFormatter={(v) => `${v}m`} />
        <Tooltip
          contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: '8px', fontSize: '12px' }}
          labelStyle={{ color: '#94a3b8' }}
          itemStyle={{ color: color }}
          formatter={(v: number) => [`${v}m`, 'Elevation']}
          labelFormatter={(v) => `${v} km`}
        />
        <Area type="monotone" dataKey="elev" stroke={color} strokeWidth={2} fill="url(#elevGradient)" dot={false} activeDot={{ r: 4, fill: color }} />
      </AreaChart>
    </ResponsiveContainer>
  )
}
