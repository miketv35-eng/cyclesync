'use client'
import { useEffect, useState } from 'react'
import { Cloud, Wind, Droplets, Thermometer, Bike } from 'lucide-react'
import { fetchWeather, getCyclingAdvisory, getWindDirection } from '@/lib/weather'
import type { Weather } from '@/types'
import { cn } from '@/lib/utils'

export function WeatherWidget({ compact = false }: { compact?: boolean }) {
  const [weather, setWeather] = useState<Weather | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      async pos => {
        const data = await fetchWeather(pos.coords.latitude, pos.coords.longitude)
        setWeather(data)
        setLoading(false)
      },
      async () => {
        const data = await fetchWeather(54.56, -1.78)
        setWeather(data)
        setLoading(false)
      }
    )
  }, [])

  if (loading) return (
    <div className="bg-surface-800 border border-slate-700/60 rounded-2xl p-5 animate-pulse">
      <div className="h-4 bg-slate-700 rounded w-24 mb-3" />
      <div className="h-10 bg-slate-700 rounded w-20 mb-2" />
      <div className="h-3 bg-slate-700 rounded w-32" />
    </div>
  )

  if (!weather) return null

  const advisory = getCyclingAdvisory(weather)
  const advisoryColor = { good: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20', caution: 'text-amber-400 bg-amber-400/10 border-amber-400/20', warning: 'text-red-400 bg-red-400/10 border-red-400/20' }[advisory.severity]

  if (compact) {
    return (
      <div className="bg-surface-800 border border-slate-700/60 rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-3xl font-bold text-white font-stat">{weather.temp}°</div>
            <div className="text-xs text-slate-400 capitalize mt-0.5">{weather.condition}</div>
          </div>
          <div className="text-right space-y-1">
            <div className="text-xs text-slate-400">Wind: <span className="text-slate-200">{weather.wind_speed} km/h {getWindDirection(weather.wind_deg)}</span></div>
            <div className="text-xs text-slate-400">Rain: <span className="text-slate-200">{weather.rain_chance}%</span></div>
          </div>
        </div>
        <div className={cn('mt-3 flex items-center gap-2 text-xs px-3 py-2 rounded-lg border', advisoryColor)}>
          <Bike className="w-3.5 h-3.5 flex-shrink-0" />
          <span>{advisory.text}</span>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-surface-800 border border-slate-700/60 rounded-2xl p-5">
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">Current Weather</div>
          <div className="text-4xl font-bold text-white font-stat">{weather.temp}°<span className="text-xl text-slate-400">C</span></div>
          <div className="text-sm text-slate-300 capitalize mt-1">{weather.condition}</div>
          <div className="text-xs text-slate-500">Feels like {weather.feels_like}°C</div>
        </div>
        <Cloud className="w-10 h-10 text-brand-400 opacity-60" />
      </div>

      <div className="grid grid-cols-3 gap-2 mb-4">
        {[
          { icon: Wind, label: 'Wind', value: `${weather.wind_speed} km/h ${getWindDirection(weather.wind_deg)}` },
          { icon: Droplets, label: 'Rain', value: `${weather.rain_chance}%` },
          { icon: Thermometer, label: 'Humidity', value: `${weather.humidity}%` },
        ].map(({ icon: I, label, value }) => (
          <div key={label} className="bg-surface-900 rounded-xl p-3 text-center">
            <I className="w-3.5 h-3.5 text-slate-400 mx-auto mb-1" />
            <div className="text-xs text-slate-500">{label}</div>
            <div className="text-xs font-medium text-slate-200 mt-0.5">{value}</div>
          </div>
        ))}
      </div>

      <div className={cn('flex items-center gap-2 text-xs px-3 py-2.5 rounded-xl border', advisoryColor)}>
        <Bike className="w-3.5 h-3.5 flex-shrink-0" />
        <span className="font-medium">{advisory.text}</span>
      </div>

      <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {weather.forecast.map((day, i) => (
          <div key={i} className="flex-1 min-w-[52px] bg-surface-900 rounded-xl p-2.5 text-center flex-shrink-0">
            <div className="text-xs text-slate-400">{day.date}</div>
            <div className="text-sm font-semibold text-white mt-1">{day.max}°</div>
            <div className="text-xs text-slate-500">{day.min}°</div>
            <div className="text-xs text-brand-400 mt-1">{day.rain_chance}%</div>
          </div>
        ))}
      </div>
    </div>
  )
}
