'use client'
import { motion } from 'framer-motion'
import { MapPin, Clock, TrendingUp, Heart, Bike } from 'lucide-react'
import { formatDistance, formatDuration, formatSpeed } from '@/lib/utils'

const MOCK_RIDES = [
  { id: '1', title: 'Morning Commute', date: '2026-03-08T07:30', distance_m: 24300, duration_s: 4080, avg_speed_kmh: 21.4, elevation_gain_m: 312, avg_heart_rate: 142, bike: 'Trek Domane SL6' },
  { id: '2', title: 'Weekend Group Ride', date: '2026-03-06T08:00', distance_m: 87600, duration_s: 13440, avg_speed_kmh: 23.5, elevation_gain_m: 1204, avg_heart_rate: 158, bike: 'Trek Domane SL6' },
  { id: '3', title: 'Evening Loop',  date: '2026-03-04T18:00', distance_m: 41200, duration_s: 6720, avg_speed_kmh: 22.1, elevation_gain_m: 487, avg_heart_rate: 149, bike: 'Giant Defy' },
  { id: '4', title: 'Hill Reps', date: '2026-03-02T07:00', distance_m: 18900, duration_s: 4440, avg_speed_kmh: 15.3, elevation_gain_m: 890, avg_heart_rate: 167, bike: 'Trek Domane SL6' },
]

export function RecentRides({ limit = 4 }: { limit?: number }) {
  const rides = MOCK_RIDES.slice(0, limit)

  return (
    <div className="bg-surface-800 border border-slate-700/60 rounded-2xl overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/60">
        <h3 className="font-semibold text-white">Recent Rides</h3>
        <a href="/profile" className="text-xs text-brand-400 hover:text-brand-300 transition-colors">View all</a>
      </div>
      <div className="divide-y divide-slate-700/40">
        {rides.map((ride, i) => (
          <motion.div
            key={ride.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-800/40 transition-colors cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center flex-shrink-0 group-hover:bg-brand-500/20 transition-colors">
              <Bike className="w-5 h-5 text-brand-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-white text-sm truncate">{ride.title}</div>
              <div className="flex items-center gap-3 mt-0.5">
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <MapPin className="w-3 h-3" />{formatDistance(ride.distance_m)}
                </span>
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />{formatDuration(ride.duration_s)}
                </span>
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />+{formatDistance(ride.elevation_gain_m)}
                </span>
              </div>
            </div>
            <div className="text-right flex-shrink-0">
              <div className="text-sm font-semibold font-stat text-brand-400">{formatSpeed(ride.avg_speed_kmh)}</div>
              {ride.avg_heart_rate && (
                <div className="text-xs text-slate-500 flex items-center gap-1 justify-end mt-0.5">
                  <Heart className="w-3 h-3 text-red-400" />{ride.avg_heart_rate}
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
