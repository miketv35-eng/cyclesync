import { cn } from '@/lib/utils'
import { LucideIcon } from 'lucide-react'

interface StatCardProps {
  label: string
  value: string
  sub?: string
  icon?: LucideIcon
  accent?: 'brand' | 'green' | 'orange' | 'violet'
  trend?: { value: string; up: boolean }
  className?: string
}

const ACCENT_MAP = {
  brand:  { text: 'text-brand-400',   bg: 'bg-brand-500/10',  border: 'border-brand-500/20'  },
  green:  { text: 'text-emerald-400', bg: 'bg-emerald-500/10',border: 'border-emerald-500/20' },
  orange: { text: 'text-orange-400',  bg: 'bg-orange-500/10', border: 'border-orange-500/20'  },
  violet: { text: 'text-violet-400',  bg: 'bg-violet-500/10', border: 'border-violet-500/20'  },
}

export function StatCard({ label, value, sub, icon: Icon, accent = 'brand', trend, className }: StatCardProps) {
  const a = ACCENT_MAP[accent]
  return (
    <div className={cn('bg-surface-800 border border-slate-700/60 rounded-2xl p-5 hover:border-slate-600 transition-colors', className)}>
      <div className="flex items-start justify-between mb-3">
        <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{label}</span>
        {Icon && (
          <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center', a.bg)}>
            <Icon className={cn('w-3.5 h-3.5', a.text)} />
          </div>
        )}
      </div>
      <div className={cn('text-2xl font-bold font-stat', a.text)}>{value}</div>
      <div className="flex items-center justify-between mt-1">
        {sub && <span className="text-xs text-slate-500">{sub}</span>}
        {trend && (
          <span className={cn('text-xs font-medium', trend.up ? 'text-emerald-400' : 'text-red-400')}>
            {trend.up ? '↑' : '↓'} {trend.value}
          </span>
        )}
      </div>
    </div>
  )
}
