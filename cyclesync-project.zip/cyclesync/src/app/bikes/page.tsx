'use client'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn, formatDistance } from '@/lib/utils'
import { Plus, Wrench, AlertTriangle, CheckCircle, ChevronRight, X, Trash2 } from 'lucide-react'

const MOCK_BIKES = [
  {
    id: '1', name: 'Trek Domane SL6', type: 'road', brand: 'Trek', model: 'Domane SL6 Disc', color: '#0ea5e9', weight_kg: 8.1, year: 2023, total_distance_m: 3842000,
    accessories: [
      { id: 'a1', name: 'Shimano 105 Di2 Drivetrain', category: 'drivetrain', brand: 'Shimano', km_used: 3842, service_interval_m: 3000000, status: 'overdue' },
      { id: 'a2', name: 'Bontrager Aeolus Pro 37 Wheels', category: 'wheels', brand: 'Bontrager', km_used: 3842, service_interval_m: 10000000, status: 'good' },
      { id: 'a3', name: 'Garmin Edge 1040', category: 'computer', brand: 'Garmin', km_used: 3842, service_interval_m: null, status: 'good' },
      { id: 'a4', name: 'Assioma Duo Power Meter', category: 'sensor', brand: 'Favero', km_used: 3842, service_interval_m: 5000000, status: 'good' },
    ]
  },
  {
    id: '2', name: 'Giant Defy Advanced', type: 'endurance', brand: 'Giant', model: 'Defy Advanced Pro 0', color: '#10b981', weight_kg: 7.6, year: 2022, total_distance_m: 1247000,
    accessories: [
      { id: 'b1', name: 'Shimano Ultegra R8100', category: 'drivetrain', brand: 'Shimano', km_used: 1247, service_interval_m: 3000000, status: 'good' },
      { id: 'b2', name: 'Wahoo ELEMNT Bolt', category: 'computer', brand: 'Wahoo', km_used: 1247, service_interval_m: null, status: 'good' },
    ]
  },
]

const CATEGORY_ICONS: Record<string, string> = { drivetrain: '⚙️', wheels: '🔵', computer: '📱', sensor: '📡', lights: '💡', other: '🔧' }

export default function BikesPage() {
  const [bikes, setBikes] = useState(MOCK_BIKES)
  const [activeBike, setActiveBike] = useState<typeof MOCK_BIKES[0] | null>(null)
  const [showAddBike, setShowAddBike] = useState(false)
  const [showAddPart, setShowAddPart] = useState(false)

  return (
    <div className="max-w-5xl mx-auto px-4 md:px-6 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-display font-bold text-white">Bike Garage</h1>
          <p className="text-slate-400 text-sm mt-1">Manage your bikes & components</p>
        </div>
        <button onClick={() => setShowAddBike(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-500 hover:bg-brand-400 text-white font-medium text-sm transition-colors"
        ><Plus className="w-4 h-4" /> Add Bike</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Bike list */}
        <div className="space-y-3">
          {bikes.map((bike, i) => {
            const overdueCount = bike.accessories.filter(a => a.status === 'overdue').length
            return (
              <motion.div key={bike.id}
                initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}
                onClick={() => setActiveBike(bike)}
                className={cn(
                  'bg-surface-800 border rounded-2xl p-4 cursor-pointer transition-all hover:border-brand-500/40',
                  activeBike?.id === bike.id ? 'border-brand-500/60 bg-brand-500/5' : 'border-slate-700/60'
                )}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex-shrink-0" style={{ background: bike.color + '22', border: `2px solid ${bike.color}44` }}>
                    <div className="w-full h-full rounded-xl flex items-center justify-center text-lg">🚲</div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-white text-sm truncate">{bike.name}</div>
                    <div className="text-xs text-slate-400 capitalize">{bike.type} · {bike.year}</div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <div className="text-sm font-bold font-stat text-brand-400">{formatDistance(bike.total_distance_m)}</div>
                    {overdueCount > 0 && (
                      <div className="flex items-center gap-1 text-xs text-amber-400 justify-end mt-0.5">
                        <AlertTriangle className="w-3 h-3" />{overdueCount} overdue
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>

        {/* Bike detail */}
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {activeBike ? (
              <motion.div key={activeBike.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
                {/* Header */}
                <div className="bg-surface-800 border border-slate-700/60 rounded-2xl p-5">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl" style={{ background: activeBike.color + '18', border: `2px solid ${activeBike.color}33` }}>🚲</div>
                    <div className="flex-1">
                      <h2 className="text-lg font-bold text-white">{activeBike.name}</h2>
                      <div className="text-sm text-slate-400 capitalize">{activeBike.brand} · {activeBike.model}</div>
                      <div className="flex gap-3 mt-1.5 text-xs text-slate-500">
                        <span>{activeBike.weight_kg} kg</span>
                        <span>·</span>
                        <span>{activeBike.year}</span>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-surface-900 rounded-xl p-3 text-center">
                      <div className="text-xs text-slate-400 mb-1">Total Distance</div>
                      <div className="text-xl font-bold font-stat text-brand-400">{formatDistance(activeBike.total_distance_m)}</div>
                    </div>
                    <div className="bg-surface-900 rounded-xl p-3 text-center">
                      <div className="text-xs text-slate-400 mb-1">Components</div>
                      <div className="text-xl font-bold font-stat text-white">{activeBike.accessories.length}</div>
                    </div>
                  </div>
                </div>

                {/* Components */}
                <div className="bg-surface-800 border border-slate-700/60 rounded-2xl overflow-hidden">
                  <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/60">
                    <h3 className="font-semibold text-white text-sm">Components</h3>
                    <button onClick={() => setShowAddPart(true)} className="text-xs text-brand-400 hover:text-brand-300 flex items-center gap-1 transition-colors">
                      <Plus className="w-3 h-3" /> Add Part
                    </button>
                  </div>
                  <div className="divide-y divide-slate-700/40">
                    {activeBike.accessories.map(acc => {
                      const pct = acc.service_interval_m ? Math.min((acc.km_used * 1000 / acc.service_interval_m) * 100, 100) : null
                      const isOverdue = acc.status === 'overdue'
                      return (
                        <div key={acc.id} className="px-5 py-3.5">
                          <div className="flex items-center gap-3">
                            <span className="text-lg flex-shrink-0">{CATEGORY_ICONS[acc.category]}</span>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium text-white">{acc.name}</span>
                                {isOverdue
                                  ? <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                                  : <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                                }
                              </div>
                              <div className="text-xs text-slate-500 mt-0.5">{acc.brand} · {acc.km_used.toLocaleString()} km used</div>
                              {pct !== null && (
                                <div className="mt-1.5">
                                  <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
                                    <div className={cn('h-full rounded-full transition-all', isOverdue ? 'bg-amber-400' : pct > 80 ? 'bg-orange-400' : 'bg-emerald-400')}
                                      style={{ width: `${pct}%` }} />
                                  </div>
                                  <div className="text-xs text-slate-500 mt-0.5">{pct.toFixed(0)}% of service interval</div>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-slate-500">
                <Wrench className="w-12 h-12 opacity-20 mb-3" />
                <p className="text-sm">Select a bike to view details</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Add Bike Modal */}
      <AnimatePresence>
        {showAddBike && (
          <motion.div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setShowAddBike(false)}
          >
            <motion.div className="bg-surface-800 border border-slate-700/60 rounded-3xl p-6 w-full max-w-md"
              initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-lg font-bold text-white">Add New Bike</h2>
                <button onClick={() => setShowAddBike(false)} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"><X className="w-4 h-4" /></button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Bike Name', ph: 'My Road Bike', col: 2 },
                  { label: 'Brand', ph: 'Trek, Giant...', col: 1 },
                  { label: 'Model', ph: 'Domane SL6', col: 1 },
                ].map(f => (
                  <div key={f.label} className={f.col === 2 ? 'col-span-2' : ''}>
                    <label className="text-xs text-slate-400 uppercase tracking-wider block mb-1.5">{f.label}</label>
                    <input placeholder={f.ph} className="w-full bg-surface-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 transition-colors" />
                  </div>
                ))}
                <div>
                  <label className="text-xs text-slate-400 uppercase tracking-wider block mb-1.5">Type</label>
                  <select className="w-full bg-surface-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-brand-500 transition-colors">
                    {['Road','Gravel','MTB','Endurance','E-Bike','TT'].map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 uppercase tracking-wider block mb-1.5">Year</label>
                  <input type="number" placeholder="2024" className="w-full bg-surface-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 transition-colors" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 uppercase tracking-wider block mb-1.5">Colour</label>
                  <input type="color" defaultValue="#0ea5e9" className="w-full h-10 bg-surface-900 border border-slate-700 rounded-xl px-2 cursor-pointer focus:outline-none focus:border-brand-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-400 uppercase tracking-wider block mb-1.5">Weight (kg)</label>
                  <input type="number" step="0.1" placeholder="8.2" className="w-full bg-surface-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 transition-colors" />
                </div>
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setShowAddBike(false)} className="flex-1 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-sm font-medium transition-colors">Cancel</button>
                <button onClick={() => setShowAddBike(false)} className="flex-1 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-400 text-white text-sm font-semibold transition-colors">Add Bike</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
