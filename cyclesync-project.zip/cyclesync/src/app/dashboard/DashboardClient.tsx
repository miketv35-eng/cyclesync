'use client'
import { motion } from 'framer-motion'
import { DashboardTiles } from '@/components/dashboard/DashboardTiles'
import { StatCard } from '@/components/shared/StatCard'
import { WeatherWidget } from '@/components/shared/WeatherWidget'
import { RecentRides } from '@/components/shared/RecentRides'
import { ElevationChart } from '@/components/shared/ElevationChart'
import { useAuth } from '@/hooks/useAuth'
import { formatDistance, formatDuration } from '@/lib/utils'
import { BarChart2, Bike, TrendingUp, Timer, Flame, Zap } from 'lucide-react'

const STATS = [
  { label: 'This Month',    value: '284 km',  sub: '+18% vs last month', icon: Bike,      accent: 'brand'  as const, trend: { value: '18%', up: true  } },
  { label: 'Total Rides',   value: '47',       sub: 'all time',           icon: BarChart2, accent: 'green'  as const },
  { label: 'Elevation',     value: '4,769 m',  sub: 'this month',         icon: TrendingUp,accent: 'orange' as const, trend: { value: '620m', up: true  } },
  { label: 'Moving Time',   value: '24h 18m',  sub: 'this month',         icon: Timer,     accent: 'violet' as const },
  { label: 'Calories',      value: '12,480',   sub: 'kcal this month',    icon: Flame,     accent: 'orange' as const },
  { label: 'Avg Speed',     value: '22.4 km/h',sub: 'this month',         icon: Zap,       accent: 'brand'  as const, trend: { value: '0.3', up: false } },
]

const container = { hidden: {}, show: { transition: { staggerChildren: 0.07 } } }
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0 } }

export function DashboardClient() {
  const { profile } = useAuth()
  const firstName = profile?.full_name?.split(' ')[0] ?? 'Rider'

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 space-y-8">
      {/* Greeting */}
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl md:text-3xl font-display font-bold text-white">
          Good morning, <span className="text-brand-400">{firstName}</span> 👋
        </h1>
        <p className="text-slate-400 text-sm mt-1">Ready to ride? Here's your overview.</p>
      </motion.div>

      {/* Stats grid */}
      <motion.div variants={container} initial="hidden" animate="show"
        className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3"
      >
        {STATS.map((s, i) => (
          <motion.div key={i} variants={item}>
            <StatCard {...s} className="h-full" />
          </motion.div>
        ))}
      </motion.div>

      {/* Tiles */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
        <DashboardTiles />
      </motion.div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Recent rides */}
        <div className="lg:col-span-2">
          <RecentRides limit={4} />
        </div>

        {/* Weather */}
        <div>
          <WeatherWidget />
        </div>
      </div>

      {/* Weekly chart */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        className="bg-surface-800 border border-slate-700/60 rounded-2xl p-5"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-white">Weekly Distance</h3>
          <div className="flex gap-2">
            {['W', 'M', 'Y'].map(p => (
              <button key={p} className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${p === 'W' ? 'bg-brand-500 text-white' : 'text-slate-400 hover:text-white bg-slate-800'}`}>{p}</button>
            ))}
          </div>
        </div>
        <ElevationChart height={140} color="#0ea5e9" />
        <div className="mt-3 flex items-center gap-6">
          <div><div className="text-xs text-slate-500">Total this week</div><div className="text-lg font-bold font-stat text-brand-400">309 km</div></div>
          <div><div className="text-xs text-slate-500">vs last week</div><div className="text-lg font-bold font-stat text-emerald-400">↑ 12%</div></div>
          <div><div className="text-xs text-slate-500">Rides</div><div className="text-lg font-bold font-stat text-white">7</div></div>
        </div>
      </motion.div>
    </div>
  )
}
